[haxe]: http://http://haxe.org
[nodejs]:http://nodejs.org/
[haxelib]:http://lib.haxe.org

# Std [haxe lib][haxelib] for [node.js][nodejs]

### Description

This library contains all you need to use haxe plus the std libary with node.js.

### History

Alternative to the [nodejs haxelib](http://lib.haxe.org/p/nodejs) library, forked due to a lack of maintenance form the other library.

This library includes code from [Ritchie Turner's haxe node.js github libraries](https://github.com/cloudshift).  There doesn't seem to be a canonical haxe std lib to match the [nodejs haxelib](http://lib.haxe.org/p/nodejs).  Many of the existing libraries have an unknown status, or have migrated to other projects.



